

```python
import matplotlib.pyplot as plt
%matplotlib inline

img = plt.imread('./Data/data/IMG/center_2016_12_01_13_30_48_287.jpg')
plt.imshow(img)
plt.show()
```


![png](output_0_0.png)



```python
import glob
import os.path
import csv
import cv2
import numpy as np
import matplotlib.pyplot as plt
#%matplotlib inline

def read_cvs(dir_path):
    lines =[]
    with open(dir_path+"/driving_log.csv") as csvfile:
        reader = csv.reader(csvfile)
        line = reader.__next__()
        for line in reader:
            lines.append({'center': dir_path + '/IMG/' + line[0].split('/')[-1],
            'left': dir_path + '/IMG/' + line[1].split('/')[-1],
            'right': dir_path + '/IMG/' + line[2].split('/')[-1],
            'steering': float(line[3]),
            'throttle': float(line[4]),
            'brake': float(line[5]),
            'speed': float(line[6])})
    return lines

def get_data(data_name, data_ref):
    output = []
    if (data_name=="center" or data_name=="center" or data_name=="center"):
        for d in data_ref:
            output.append(cv2.imread(d[data_name]))
    elif (data_name=="steering" or data_name=="throttle" or data_name=="brake" or data_name=="speed"):
        for d in data_ref:
            output.append(d[data_name])
    return output

dirs = glob.glob("./Data/*")
inputDirs = []
for fname in dirs:
    if (os.path.exists(fname+"/driving_log.csv")):
        inputDirs.append(fname)
print("{0} director(y/ies) as input data found.".format(len(inputDirs)))

data_dir = inputDirs[0]
data_references = read_cvs(data_dir)
```

    3 director(y/ies) as input data found.



```python
no_image = len(data_references)
delta = no_image // 6
for i in range(5):
    center_image = plt.imread(data_references[i*delta]["center"])
    left_image = plt.imread(data_references[i*delta]["left"])
    right_image = plt.imread(data_references[i*delta]["right"])
    fig = plt.figure(figsize=(12,6))
    plt.subplot(1,3,1)
    plt.imshow(left_image)
    plt.subplot(1,3,2)
    plt.imshow(center_image)
    plt.subplot(1,3,3)
    plt.imshow(right_image)
    plt.show()

```


![png](output_2_0.png)



![png](output_2_1.png)



![png](output_2_2.png)



![png](output_2_3.png)



![png](output_2_4.png)



```python
no_image = len(data_references)
delta = no_image // 6
for i in range(5):
    center_image = plt.imread(data_references[i*delta]["center"])
    left_image = plt.imread(data_references[i*delta]["left"])
    right_image = plt.imread(data_references[i*delta]["right"])
    fig = plt.figure(figsize=(12,6))
    plt.subplot(1,3,1)
    plt.imshow(left_image[61:110,20:300])
    plt.subplot(1,3,2)
    plt.imshow(center_image[61:110,20:300])
    plt.subplot(1,3,3)
    plt.imshow(right_image[61:110,20:300])
    plt.show()

```


![png](output_3_0.png)



![png](output_3_1.png)



![png](output_3_2.png)



![png](output_3_3.png)



![png](output_3_4.png)



```python
import cv2

cols=320
rows=160

M_toright = np.float32([[1,0,20],[0,1,0]])
M_toleft  = np.float32([[1,0,-20],[0,1,0]])
dst = cv2.warpAffine(center_image,M_toleft,(cols,rows))

no_image = len(data_references)
delta = no_image // 6
for i in range(5):
    center_image = plt.imread(data_references[i*delta]["center"])
    left_image = plt.imread(data_references[i*delta]["left"])
    right_image = plt.imread(data_references[i*delta]["right"])
    fig = plt.figure(figsize=(12,6))
    plt.subplot(1,3,1)
    plt.imshow(cv2.warpAffine(center_image,M_toleft,(cols,rows))[61:110,20:300])
    plt.subplot(1,3,2)
    plt.imshow(center_image[61:110,20:300])
    plt.subplot(1,3,3)
    plt.imshow(cv2.warpAffine(center_image,M_toright,(cols,rows))[61:110,20:300])
    plt.show()

```


![png](output_4_0.png)



![png](output_4_1.png)



![png](output_4_2.png)



![png](output_4_3.png)



![png](output_4_4.png)



```python

# load and evaluate a saved model
from numpy import loadtxt
from keras.models import load_model

# load model
model = load_model('model_lenet_1.h5')
# summarize model.
model.summary()
center_image = plt.imread(data_references[i*delta]["center"])
left_image = plt.imread(data_references[i*delta]["left"])
right_image = plt.imread(data_references[i*delta]["right"])
# load dataset
# dataset = loadtxt("pima-indians-diabetes.csv", delimiter=",")
# # split into input (X) and output (Y) variables
# X = dataset[:,0:8]
# Y = dataset[:,8]
# # evaluate the model
# score = model.evaluate(X, Y, verbose=0)
# print("%s: %.2f%%" % (model.metrics_names[1], score[1]*100))
```

    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    cropping2d_1 (Cropping2D)    (None, 50, 320, 3)        0         
    _________________________________________________________________
    lambda_1 (Lambda)            (None, 50, 320, 3)        0         
    _________________________________________________________________
    conv2d_1 (Conv2D)            (None, 48, 318, 6)        168       
    _________________________________________________________________
    max_pooling2d_1 (MaxPooling2 (None, 24, 159, 6)        0         
    _________________________________________________________________
    conv2d_2 (Conv2D)            (None, 22, 157, 16)       880       
    _________________________________________________________________
    max_pooling2d_2 (MaxPooling2 (None, 11, 78, 16)        0         
    _________________________________________________________________
    flatten_1 (Flatten)          (None, 13728)             0         
    _________________________________________________________________
    dropout_1 (Dropout)          (None, 13728)             0         
    _________________________________________________________________
    dense_1 (Dense)              (None, 120)               1647480   
    _________________________________________________________________
    dropout_2 (Dropout)          (None, 120)               0         
    _________________________________________________________________
    dense_2 (Dense)              (None, 84)                10164     
    _________________________________________________________________
    dropout_3 (Dropout)          (None, 84)                0         
    _________________________________________________________________
    dense_3 (Dense)              (None, 1)                 85        
    =================================================================
    Total params: 1,658,777
    Trainable params: 1,658,777
    Non-trainable params: 0
    _________________________________________________________________



```python
from keras import backend as K
no_image = len(data_references)
delta = no_image // 6
for i in range(5):
    center_image = plt.imread(data_references[i*delta]["center"])
    left_image = plt.imread(data_references[i*delta]["left"])
    right_image = plt.imread(data_references[i*delta]["right"])
    print(model.predict(np.array([left_image, center_image, right_image]),batch_size=1))
    print(data_references[i*delta]["steering"])

```

    [[0.11180291]
     [0.12030616]
     [0.11516395]]
    0.0
    [[ 0.1604893 ]
     [ 0.12357687]
     [-0.04200038]]
    0.07132844
    [[ 0.14266515]
     [ 0.06523529]
     [-0.06901023]]
    0.0
    [[ 0.11374358]
     [-0.00692343]
     [-0.07281094]]
    0.0
    [[ 0.02822321]
     [-0.07465266]
     [-0.1449394 ]]
    -0.1452064



```python
model.get_layer("conv2d_1").trainable=False
```


```python
import pandas as pd
log=pd.read_csv("Data/data/driving_log.csv")
log
log.steering.hist(bins=101, range=[-0.5,0.5])
plt.show()
```


![png](output_8_0.png)

